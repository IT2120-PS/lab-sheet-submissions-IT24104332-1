setwd("C:/Users/it24104332/Desktop/Lab 04")
getwd()

#1
branch_data <- read.csv("Exercise.txt", header = TRUE, sep = ",")

fix(branch_data)
attach(branch_data)
attach(branch_data)


#2
#view the structure of the data
str(branch_data)

#Branch - Nominal(Cateorical)
#Sales_X1 - Ratio(Numerical)
#Advertising_X2 - Ratio(Numerical)
#Years_X3 - Ratio (Integer)

#3
boxplot(branch_data$Sales_X1,main = "Boxplot of Sales",ylab = "Sales")

#4
#get five number summary for advertising_X2
summary(Advertising_X2)
quantile(Advertising_X2)

#Getting IQR for Advertising_X2
IQR(Advertising_X2)

#5
find_outliers <- function(x) {
  q1<- quantile(x,0.25)
  q3<- quantile(x,0.75)
  IQR <- q3-q1
  lower_bound <- q1 - 1.5 * IQR
  upper_bound <- q3 + 1.5 * IQR
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}


find_outliers(branch_data$Years_X3)












